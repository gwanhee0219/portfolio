function inputCheck( ) {
	if(document.regFrm.id.value=="") {
		alert("아이디를 입력하세요.");
		document.regFrm.id.focus( );
		return;
	}
	if(document.regFrm.pwd.value=="") {
		alert("비밀번호를 입력하세요.");
		document.regFrm.pass.focus( );
		return;
	}
	if(document.regFrm.repwd.value=="") {
		alert("비밀번호 확인을 입력하세요.");
		document.regFrm.repass.focus( );
		return;
	}
	if(document.regFrm.pwd.value != document.regFrm.repwd.value) {
		alert("비밀번호가 일치하지 않습니다.");
		document.regFrm.repwd.value="";
		document.regFrm.repwd.focus( );
		return;
	}
	if(document.regFrm.name.value=="") {
		alert("이름을 입력해 주세요.");
		document.regFrm.name.focus( );
		return;
	}
	
	document.regFrm.submit( );
}

function win_close( ) {
	self.close( );
}

package com.abo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

import ark.dbcp.DBConnectionMgr; // DBCP


public class CocktailMgr {
	
	private DBConnectionMgr pool;
	private Connection con = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private String sql = null;
	
	public CocktailMgr( ) { // xxxPro.jsp ���Ͽ��� DAO ��ü�� �����ϸ� Ŀ�ؼ� Ǯ ��ü�� ���´�.
		try {
			pool = DBConnectionMgr.getInstance( );
			// Ŀ�ؼ� Ǯ ��ü�� ���´�.
		}catch(Exception e) {
			e.printStackTrace( );
		}
	}
	
	public Vector<CocktailBean> searchCtname(String ctname) {
		Vector<CocktailBean> vlist = new Vector<CocktailBean>( );
		
		try {
			con = pool.getConnection( );
			sql = "select * from tblabococktail where ctname like ? order by ctname";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + ctname + "%");
			rs = pstmt.executeQuery( );
			while (rs.next( )) { 
				CocktailBean ctbean = new CocktailBean();
				ctbean.setCtname(rs.getString(1));
				ctbean.setCtimage(rs.getString(2));
				ctbean.setColor(rs.getString(3));
				ctbean.setSpirits(rs.getString(4));
				ctbean.setFlavor(rs.getString(5));
				ctbean.setAddinfo(rs.getString(6));
				vlist.add(ctbean);
			}
		}
		catch(Exception e) { e.printStackTrace( ); } 
		finally { pool.freeConnection(con, pstmt, rs); }
		return vlist;
	}
	
	public Vector<CocktailBean> searchTaste(String color, String spirits, String flavor) {
		Vector<CocktailBean> vlist = new Vector<CocktailBean>( );
		
		try {
			con = pool.getConnection( );
			sql = "select * from tblabococktail where color=? or spirits=? or flavor=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, color);
			pstmt.setString(2, spirits);
			pstmt.setString(3, flavor);
			rs = pstmt.executeQuery( );
			while (rs.next( )) { 
				CocktailBean ctbean = new CocktailBean();
				ctbean.setCtname(rs.getString(1));
				ctbean.setCtimage(rs.getString(2));
				ctbean.setColor(rs.getString(3));
				ctbean.setSpirits(rs.getString(4));
				ctbean.setFlavor(rs.getString(5));
				ctbean.setAddinfo(rs.getString(6));
				vlist.add(ctbean);
			}
		}
		catch(Exception e) { e.printStackTrace( ); } 
		finally { pool.freeConnection(con, pstmt, rs); }
		return vlist;
	}
	
	public Vector<CocktailBean> searchInterest(String idKey) {
		Vector<CocktailBean> vlist = new Vector<CocktailBean>( );
		
		try {
			con = pool.getConnection( );
			sql = "select id, spirits, flavor, color from tblabomember where id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, idKey);
			rs = pstmt.executeQuery( );
			rs.next();
			String id = rs.getString(1);
			String spirits = rs.getString(2);
			String flavor = rs.getString(3);
			String color = rs.getString(4);
			
			sql = "select * from tblabococktail where spirits=? or flavor=? or color=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, spirits);
			pstmt.setString(2, flavor);
			pstmt.setString(3, color);
			rs = pstmt.executeQuery( );
			while (rs.next( )) { 
				CocktailBean ctbean = new CocktailBean();
				ctbean.setCtname(rs.getString(1));
				ctbean.setCtimage(rs.getString(2));
				ctbean.setColor(rs.getString(3));
				ctbean.setSpirits(rs.getString(4));
				ctbean.setFlavor(rs.getString(5));
				ctbean.setAddinfo(rs.getString(6));
				vlist.add(ctbean);
			}
		}
		catch(Exception e) { e.printStackTrace( ); } 
		finally { pool.freeConnection(con, pstmt, rs); }
		return vlist;
	}
	
	public Vector<CocktailBean> searchAll() {
		Vector<CocktailBean> vlist = new Vector<CocktailBean>( );
		
		try {
			con = pool.getConnection( );
			sql = "select * from tblabococktail";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery( );
			while (rs.next( )) { 
				CocktailBean ctbean = new CocktailBean();
				ctbean.setCtname(rs.getString(1));
				ctbean.setCtimage(rs.getString(2));
				ctbean.setColor(rs.getString(3));
				ctbean.setSpirits(rs.getString(4));
				ctbean.setFlavor(rs.getString(5));
				ctbean.setAddinfo(rs.getString(6));
				vlist.add(ctbean);
			}
		}
		catch(Exception e) { e.printStackTrace( ); } 
		finally { pool.freeConnection(con, pstmt, rs); }
		return vlist;
	}
	
	public void writeCocktail(CocktailBean ctbean) {
		try {
			con = pool.getConnection( );
			sql = "insert into tblabococktail(ctname, ctimage, color, spirits, flavor, addinfo)"
					+"values(?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ctbean.getCtname());
			pstmt.setString(2, ctbean.getCtimage());
			pstmt.setString(3, ctbean.getColor());
			pstmt.setString(4, ctbean.getSpirits());
			pstmt.setString(5, ctbean.getFlavor());
			pstmt.setString(6, ctbean.getAddinfo());
			pstmt.executeUpdate( );
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
	}

	public void updateCocktail(CocktailBean ctbean, String oldctname) {
		try {
			con = pool.getConnection( );
			// conn.setAutoCommit(false); // Ʈ����� ���� ���� ���̺� ������ ���� AutoCommit�� ����
			sql = "update tblabococktail set ctname=?, ctimage=?, color=?, spirits=?, flavor=?, addinfo=? where ctname=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ctbean.getCtname());
			pstmt.setString(2, ctbean.getCtimage());
			pstmt.setString(3, ctbean.getColor());
			pstmt.setString(4, ctbean.getSpirits());
			pstmt.setString(5, ctbean.getFlavor());
			pstmt.setString(6, ctbean.getAddinfo());
			pstmt.setString(7, oldctname);
			pstmt.executeUpdate( );
			// conn.commit( ); // ���� ���̺� ���� �� ������ ������ commit ó��	
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			pool.freeConnection(con, pstmt, rs);
		}
	}
	
	public CocktailBean getCtInfo(String oldctname) {
		CocktailBean ctbean = new CocktailBean( );
		
		try {
			con = pool.getConnection( );
			sql = "select * from tblabococktail where ctname = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, oldctname);
			rs = pstmt.executeQuery( );
			while (rs.next( )) { 
				ctbean.setCtname(rs.getString("ctname"));
				ctbean.setCtimage(rs.getString("ctimage"));	
				ctbean.setColor(rs.getString("color"));
				ctbean.setSpirits(rs.getString("spirits"));
				ctbean.setFlavor(rs.getString("flavor"));
				ctbean.setAddinfo(rs.getString("addinfo"));
				
				if (ctbean.getCtimage() == null || ctbean.getCtimage().equals("")) ctbean.setCtimage("sample.jpg");
			}
		}
		catch(Exception e) { e.printStackTrace( ); } 
		finally { pool.freeConnection(con, pstmt, rs); }
		return ctbean;
	}
	
	
}

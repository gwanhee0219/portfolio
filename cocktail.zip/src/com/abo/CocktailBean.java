package com.abo;

public class CocktailBean {
	private String ctname, ctimage, color, spirits, flavor, addinfo;

	public String getCtname() {
		return ctname;
	}

	public void setCtname(String ctname) {
		this.ctname = ctname;
	}

	public String getCtimage() {
		return ctimage;
	}

	public void setCtimage(String ctimage) {
		this.ctimage = ctimage;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSpirits() {
		return spirits;
	}

	public void setSpirits(String spirits) {
		this.spirits = spirits;
	}

	public String getFlavor() {
		return flavor;
	}

	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	public String getAddinfo() {
		return addinfo;
	}

	public void setAddinfo(String addinfo) {
		this.addinfo = addinfo;
	}

	

}
